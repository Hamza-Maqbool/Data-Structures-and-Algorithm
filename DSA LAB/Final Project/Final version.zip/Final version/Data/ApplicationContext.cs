﻿namespace WebsiteOfUetMap.Data
{
    public class ApplicationContext
    {
    }
}
